from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # this is for home page!
    path('Login/', views.Login, name='Login'),
    path('Register/', views.Register, name='Register'),
    path('Signup/', views.Signup, name='Signup'),
    path('UserLogin/', views.UserLogin, name='UserLogin'),
    path('AddProduct/', views.AddProduct, name='AddProduct'),
    path('AddProductAction/', views.AddProductAction, name='AddProductAction'),
    path('UpdateTracing/', views.UpdateTracing, name='UpdateTracing'),
    path('UpdateTracingAction/', views.UpdateTracingAction, name='UpdateTracingAction'),
    path('ViewTracing/', views.ViewTracing, name='ViewTracing'),
    path('AddTracingAction/', views.AddTracingAction, name='AddTracingAction'),
]
