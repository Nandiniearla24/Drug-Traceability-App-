from django.apps import AppConfig


class DrugtraceappConfig(AppConfig):
    name = 'DrugTraceApp'
